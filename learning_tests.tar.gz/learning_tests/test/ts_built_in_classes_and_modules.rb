$:.unshift File.join( File.dirname( __FILE__ ) )

#!/usr/bin/env ruby -w

require 'test/unit'
require 'tc_string'
require 'tc_array'

